#pragma once
#include <vector>
using namespace std;

void
find_minmax(vector<double> numbers, double& min, double& max);
